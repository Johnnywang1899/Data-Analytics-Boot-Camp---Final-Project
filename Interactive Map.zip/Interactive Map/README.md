# Mapping_Earthquakes
JavaScript, D3, Leaflet, Mapbox, GeoJSON  
Apply Leaflet library and Mapbox using JavaScript to create a map based on earthquake records. 
Through collecting earthquake data by GeoJSON, the tectonic plate data is shown with lines on the map. The marker size shown on the map indicates the magnitude of the earthquake observed  
![Earthquake.png](image/Earthquake.png)
