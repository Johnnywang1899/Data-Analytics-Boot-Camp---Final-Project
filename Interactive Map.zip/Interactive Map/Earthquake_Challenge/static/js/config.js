// API key
const API_KEY = "pk.eyJ1Ijoiam9obm55d2FuZzE4OTkiLCJhIjoiY2ttaHdubHE0MGJpYjJ1bW4zdDRpODFwdSJ9.s_P25BIyrfUE6Z7O0Vb9bg";