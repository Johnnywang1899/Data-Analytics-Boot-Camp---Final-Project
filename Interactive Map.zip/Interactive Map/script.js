console.log("Coding can be diffecult");
console.log("but git makes it easier");
console.log("hahaha update wow")